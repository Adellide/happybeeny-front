# Wafer Measurement Dashboard

상단 그리드 + 하단 다중 차트(가변 개수) 대시보드.
서버 상태는 React Query, 차트별 UI 상태(X/Y축·차트타입)는 Zustand로 분리했습니다.

## 1. 설치

```bash
npm install antd @ant-design/icons ag-grid-community ag-grid-react \
  echarts echarts-for-react zustand @tanstack/react-query axios
```

## 2. 폴더 구조

```
src/
  App.jsx                        # QueryClientProvider 설정 진입점
  store/useDashboardStore.js     # 차트별 UI 상태 (Zustand)
  hooks/useWaferMeasurements.js  # 서버 데이터 fetch (React Query)
  utils/dataUtils.js             # X/Y축 후보 추출, 집계 로직
  components/
    Dashboard.jsx                # 그리드 + 차트 목록 조합
    DataGridPanel.jsx            # AG Grid
    ChartPanel.jsx               # 개별 차트 (X/Y축, 타입 selectbox + 좌측 툴박스)
  data/sampleData.json           # 제공해주신 샘플 데이터
```

## 3. 실제 API 연결 전 샘플 데이터로 먼저 테스트하기

`useWaferMeasurements.js`의 `queryFn`을 아래처럼 바꾸면 API 없이 바로 동작 확인이 가능합니다.

```js
queryFn: async () => (await import("../data/sampleData.json")).default,
```

실제 API가 준비되면 다시 axios 호출 부분으로 되돌리고, 엔드포인트/쿼리 파라미터만 맞춰주시면 됩니다.

## 4. 동작 방식

### X축 / Y축 자동 후보 추출 (`utils/dataUtils.js`)
데이터의 첫 번째 행을 기준으로 필드 타입을 검사합니다.
- `string` 타입 → X축(카테고리) 후보: `fab`, `date`, `eqp`, `chamber`, `lot`
- `number` 타입 → Y축(시리즈) 후보: `step1`, `step2`, `step3`, `step4`

만약 나중에 필드가 추가/변경되어도(예: `recipe`, `operator` 필드 추가) 코드 수정 없이 selectbox 옵션이 자동으로 늘어납니다.

### 동일 X값이 여러 행에 걸쳐 있는 경우 (집계)
예를 들어 `eqp`를 X축으로 선택하면 `EQP-101`이 `chamber A/B`, 여러 `date`에 걸쳐 중복 존재합니다.
`aggregateByAxis()`가 X값 기준으로 그룹핑 후 Y값들의 **평균**을 계산해 하나의 포인트로 만들어줍니다.
(다른 집계 방식—합계, 최대/최소 등—이 필요하시면 이 함수만 바꾸면 전체에 반영됩니다.)

### 차트별 상태 격리 (Zustand)
```js
charts: {
  'chart-1': { xAxisKey: 'eqp', yAxisKeys: ['step1','step2'], chartType: 'line' },
  'chart-2': { xAxisKey: 'chamber', yAxisKeys: ['step3'], chartType: 'bar' },
}
```
각 `ChartPanel`은 `useDashboardStore((state) => state.charts[chartId])`로 **자기 chartId만 구독**하므로,
다른 차트의 축/타입 변경이 있어도 리렌더링되지 않습니다.

### 차트 추가/삭제
`Dashboard.jsx`의 "차트 추가" 버튼 → `addChart()` 호출 → `chartOrder` 배열에 새 chartId 추가 →
새 `ChartPanel`이 렌더링됩니다. 각 카드의 X 아이콘으로 개별 삭제도 가능합니다.

### 차트 좌측 툴박스 (프린트 / 확대 / 복원 / 이미지저장)
ECharts 내장 `toolbox`를 `orient: 'vertical'`, `left`로 배치했습니다.
- **프린트**: `getDataURL()`로 차트를 이미지화 → 새 창에서 `window.print()` 호출
- **확대(dataZoom)**: 드래그로 영역 확대, **복원(restore)** 으로 원상복귀
- **이미지 저장(saveAsImage)**: PNG로 다운로드

커스텀 아이콘/기능이 더 필요하면(예: CSV 다운로드) `ChartPanel.jsx`의 `toolbox.feature`에 추가하시면 됩니다.

## 5. 다음 확장 포인트

- **그리드 행 선택 → 차트 필터 연동**: `useDashboardStore`에 이미 `selectedRowIds` 상태를 만들어뒀습니다.
  AG Grid `onSelectionChanged`에서 `setSelectedRowIds()`를 호출하고, `Dashboard.jsx`에서 `rowData`를
  필터링해 `ChartPanel`에 넘기면 바로 연동됩니다.
- **AG Grid Enterprise 기능** (boxplot, pivot 등)을 쓰신다면 `DataGridPanel.jsx`에
  `import "ag-grid-enterprise";` 및 라이선스 키만 추가하면 됩니다.
- **날짜(date) 필드를 진짜 시계열 X축으로** 쓰고 싶다면 `xAxis.type: 'category'` 대신
  `'time'`으로 바꾸고 date 파싱 로직을 `dataUtils.js`에 추가하면 됩니다.
