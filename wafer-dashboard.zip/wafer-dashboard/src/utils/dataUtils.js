/**
 * dataUtils.js
 * ------------------------------------------------------------------
 * 백엔드에서 받은 rowData(object[])를 분석해서
 *  - X축으로 쓸 수 있는 카테고리형 필드 목록
 *  - Y축으로 쓸 수 있는 숫자형 필드 목록
 * 을 자동으로 추출하고, 차트 렌더링을 위한 집계 로직을 제공합니다.
 *
 * 예시 데이터 기준:
 *   카테고리형(X축 후보): fab, date, eqp, chamber, lot
 *   숫자형(Y축 후보)   : step1, step2, step3, step4
 */

/** rowData의 첫 행을 기준으로 필드를 string/number 타입으로 분류 */
export function inferFieldTypes(rowData) {
  if (!rowData?.length) return { categoricalKeys: [], numericKeys: [] };

  const sample = rowData[0];
  const categoricalKeys = [];
  const numericKeys = [];

  Object.keys(sample).forEach((key) => {
    const value = sample[key];
    if (typeof value === "number") {
      numericKeys.push(key);
    } else {
      // string, date-string 등은 전부 카테고리(축) 후보로 취급
      categoricalKeys.push(key);
    }
  });

  return { categoricalKeys, numericKeys };
}

/**
 * X축 필드(xAxisKey) 기준으로 그룹핑 후, yAxisKeys 각각의 평균을 집계.
 * 같은 X값이 여러 행에 걸쳐 존재할 수 있는 fab 데이터 특성(예: eqp별로 여러 chamber)을
 * 고려해 line/bar/area/scatter 공통으로 사용할 수 있게 평균 집계합니다.
 *
 * 반환 형태: { categories: string[], seriesData: { [yKey]: number[] } }
 */
export function aggregateByAxis(rowData, xAxisKey, yAxisKeys) {
  if (!rowData?.length || !xAxisKey || !yAxisKeys?.length) {
    return { categories: [], seriesData: {} };
  }

  // 그룹핑: { [xValue]: row[] }
  const groups = new Map();
  rowData.forEach((row) => {
    const xValue = String(row[xAxisKey]);
    if (!groups.has(xValue)) groups.set(xValue, []);
    groups.get(xValue).push(row);
  });

  const categories = Array.from(groups.keys());
  const seriesData = {};

  yAxisKeys.forEach((yKey) => {
    seriesData[yKey] = categories.map((xValue) => {
      const rows = groups.get(xValue);
      const sum = rows.reduce((acc, r) => acc + (Number(r[yKey]) || 0), 0);
      return Number((sum / rows.length).toFixed(3));
    });
  });

  return { categories, seriesData };
}

/** 파이 차트용: xAxisKey 카테고리별 단일 yKey 값 집계(합계) */
export function aggregateForPie(rowData, xAxisKey, yKey) {
  if (!rowData?.length || !xAxisKey || !yKey) return [];

  const groups = new Map();
  rowData.forEach((row) => {
    const xValue = String(row[xAxisKey]);
    groups.set(xValue, (groups.get(xValue) || 0) + (Number(row[yKey]) || 0));
  });

  return Array.from(groups.entries()).map(([name, value]) => ({
    name,
    value: Number(value.toFixed(3)),
  }));
}
