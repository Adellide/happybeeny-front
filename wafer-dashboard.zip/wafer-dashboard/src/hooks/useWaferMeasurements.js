import { useQuery } from "@tanstack/react-query";
import axios from "axios";

/**
 * useWaferMeasurements
 * ------------------------------------------------------------------
 * 백엔드 API에서 fab 계측 데이터를 가져오는 React Query 훅.
 * 실제 엔드포인트로 교체해서 사용하세요.
 *
 * 응답 형태 (배열):
 * [
 *   { fab, date, eqp, chamber, lot, step1, step2, step3, step4 },
 *   ...
 * ]
 */
export function useWaferMeasurements(params = {}) {
  return useQuery({
    queryKey: ["waferMeasurements", params],
    queryFn: async () => {
      const { data } = await axios.get("/api/wafer-measurements", { params });
      return data;
    },
    staleTime: 60_000, // 1분간 재요청 없이 캐시 사용
    // 개발 중 실제 API가 없다면 아래처럼 sampleData로 대체해서 테스트하세요:
    // queryFn: async () => (await import("../data/sampleData.json")).default,
  });
}
