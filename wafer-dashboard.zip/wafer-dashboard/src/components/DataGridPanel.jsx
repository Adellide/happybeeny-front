import React, { useMemo } from "react";
import { Card } from "antd";
import { AgGridReact } from "ag-grid-react";

import "ag-grid-community/styles/ag-grid.css";
import "ag-grid-community/styles/ag-theme-quartz.css";

/**
 * DataGridPanel
 * ------------------------------------------------------------------
 * 백엔드에서 받아온 rowData를 그대로 그리드로 표시합니다.
 * 컬럼은 데이터 키 기반으로 자동 생성됩니다.
 */
export default function DataGridPanel({ rowData, loading }) {
  const columnDefs = useMemo(() => {
    if (!rowData?.length) return [];
    return Object.keys(rowData[0]).map((key) => ({
      field: key,
      headerName: key,
      sortable: true,
      filter: true,
      resizable: true,
      flex: 1,
    }));
  }, [rowData]);

  const defaultColDef = useMemo(
    () => ({ sortable: true, filter: true, resizable: true, minWidth: 100 }),
    []
  );

  return (
    <Card title="계측 데이터" size="small" loading={loading}>
      <div className="ag-theme-quartz" style={{ height: 340, width: "100%" }}>
        <AgGridReact
          rowData={rowData ?? []}
          columnDefs={columnDefs}
          defaultColDef={defaultColDef}
          animateRows
          pagination
          paginationPageSize={10}
        />
      </div>
    </Card>
  );
}
