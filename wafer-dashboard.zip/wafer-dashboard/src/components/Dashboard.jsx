import React, { useEffect, useMemo } from "react";
import { Button, Space, Alert, Row, Col } from "antd";
import { PlusOutlined } from "@ant-design/icons";

import { useWaferMeasurements } from "../hooks/useWaferMeasurements";
import { useDashboardStore } from "../store/useDashboardStore";
import { inferFieldTypes } from "../utils/dataUtils";
import DataGridPanel from "./DataGridPanel";
import ChartPanel from "./ChartPanel";

/**
 * Dashboard
 * ------------------------------------------------------------------
 * 상단: 그리드 (React Query로 가져온 서버 데이터)
 * 하단: 차트 패널 N개 (Zustand chartOrder 순서대로 렌더링, 개수 가변)
 */
export default function Dashboard() {
  const { data: rowData, isLoading, isError, error } = useWaferMeasurements();

  const chartOrder = useDashboardStore((state) => state.chartOrder);
  const charts = useDashboardStore((state) => state.charts);
  const addChart = useDashboardStore((state) => state.addChart);
  const removeChart = useDashboardStore((state) => state.removeChart);
  const initChartOrder = useDashboardStore((state) => state.initChartOrder);

  useEffect(() => {
    initChartOrder();
  }, [initChartOrder]);

  const { categoricalKeys, numericKeys } = useMemo(
    () => inferFieldTypes(rowData ?? []),
    [rowData]
  );

  if (isError) {
    return (
      <Alert
        type="error"
        message="데이터를 불러오지 못했습니다"
        description={error?.message}
        showIcon
      />
    );
  }

  return (
    <Space direction="vertical" size={16} style={{ width: "100%" }}>
      <DataGridPanel rowData={rowData} loading={isLoading} />

      <Row justify="end">
        <Button
          type="primary"
          icon={<PlusOutlined />}
          onClick={() => addChart()}
          disabled={!rowData?.length}
        >
          차트 추가
        </Button>
      </Row>

      <Row gutter={[16, 16]}>
        {chartOrder
          .filter((chartId) => charts[chartId]) // 삭제된 차트 방어
          .map((chartId) => (
            <Col key={chartId} xs={24} xl={12}>
              <ChartPanel
                chartId={chartId}
                rowData={rowData ?? []}
                categoricalKeys={categoricalKeys}
                numericKeys={numericKeys}
                onRemove={removeChart}
              />
            </Col>
          ))}
      </Row>
    </Space>
  );
}
