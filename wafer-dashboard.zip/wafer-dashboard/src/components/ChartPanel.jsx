import React, { useMemo, useRef } from "react";
import { Card, Select, Space, Typography, Button, Tooltip } from "antd";
import { CloseOutlined } from "@ant-design/icons";
import ReactECharts from "echarts-for-react";

import { useDashboardStore } from "../store/useDashboardStore";
import { aggregateByAxis, aggregateForPie } from "../utils/dataUtils";

const { Text } = Typography;

const CHART_TYPE_OPTIONS = [
  { label: "라인", value: "line" },
  { label: "바", value: "bar" },
  { label: "영역", value: "area" },
  { label: "파이", value: "pie" },
  { label: "스캐터", value: "scatter" },
];

/**
 * ChartPanel
 * ------------------------------------------------------------------
 * chartId로 Zustand 스토어에서 자신의 설정(xAxisKey, yAxisKeys, chartType)만
 * 구독합니다. 다른 차트의 설정 변경은 이 컴포넌트를 리렌더링하지 않습니다.
 *
 * - 상단: X축 선택 / Y축(다중) 선택 / 차트 타입 선택
 * - 차트 좌측: ECharts 내장 toolbox (프린트/확대/복원)
 */
export default function ChartPanel({
  chartId,
  rowData,
  categoricalKeys,
  numericKeys,
  onRemove,
}) {
  const chartRef = useRef(null);

  const config = useDashboardStore((state) => state.charts[chartId]);
  const setXAxisKey = useDashboardStore((state) => state.setXAxisKey);
  const setYAxisKeys = useDashboardStore((state) => state.setYAxisKeys);
  const setChartType = useDashboardStore((state) => state.setChartType);

  const xAxisOptions = useMemo(
    () => categoricalKeys.map((key) => ({ label: key, value: key })),
    [categoricalKeys]
  );
  const yAxisOptions = useMemo(
    () => numericKeys.map((key) => ({ label: key, value: key })),
    [numericKeys]
  );

  // 최초 렌더 시 기본 축 설정 (스토어에 값이 없으면 첫 후보로 자동 지정)
  const effectiveXAxisKey = config?.xAxisKey ?? categoricalKeys[0];
  const effectiveYAxisKeys = config?.yAxisKeys?.length
    ? config.yAxisKeys
    : numericKeys.slice(0, 2);

  // ------------------------------------------------------------------
  // 프린트: 현재 차트를 이미지로 추출해 새 창에서 인쇄
  // ------------------------------------------------------------------
  const handlePrint = () => {
    const instance = chartRef.current?.getEchartsInstance();
    if (!instance) return;
    const dataUrl = instance.getDataURL({ pixelRatio: 2, backgroundColor: "#fff" });
    const printWindow = window.open("", "_blank");
    printWindow.document.write(
      `<img src="${dataUrl}" style="width:100%" onload="window.print(); window.close();" />`
    );
    printWindow.document.close();
  };

  // ------------------------------------------------------------------
  // ECharts 옵션 생성
  // ------------------------------------------------------------------
  const option = useMemo(() => {
    const chartType = config?.chartType ?? "line";
    const xKey = effectiveXAxisKey;
    const yKeys = effectiveYAxisKeys;

    // 좌측에 배치할 공통 toolbox: 프린트(커스텀) + 확대(dataZoom) + 복원 + 이미지저장
    const toolbox = {
      orient: "vertical",
      left: 6,
      top: "middle",
      itemSize: 14,
      feature: {
        myPrint: {
          show: true,
          title: "프린트",
          icon: "path://M480 96H160c-17.7 0-32 14.3-32 32v320h64V160h288v288h64V128c0-17.7-14.3-32-32-32zM128 512h768v64H128zM192 640h640v256H192z",
          onclick: handlePrint,
        },
        dataZoom: {
          show: true,
          title: { zoom: "확대", back: "확대 취소" },
          yAxisIndex: "none",
        },
        restore: { show: true, title: "초기화" },
        saveAsImage: { show: true, title: "이미지 저장" },
      },
    };

    if (chartType === "pie") {
      const yKey = yKeys[0];
      const pieData = yKey ? aggregateForPie(rowData, xKey, yKey) : [];
      return {
        toolbox,
        tooltip: { trigger: "item" },
        legend: { top: "bottom" },
        series: [
          {
            name: yKey ?? "",
            type: "pie",
            radius: ["35%", "65%"],
            itemStyle: { borderRadius: 6, borderColor: "#fff", borderWidth: 2 },
            label: { formatter: "{b}: {d}%" },
            data: pieData,
          },
        ],
      };
    }

    const { categories, seriesData } = aggregateByAxis(rowData, xKey, yKeys);
    const isArea = chartType === "area";

    if (chartType === "scatter") {
      return {
        toolbox,
        tooltip: { trigger: "item" },
        legend: { data: yKeys, top: 0 },
        xAxis: { type: "category", data: categories },
        yAxis: { type: "value" },
        series: yKeys.map((key) => ({
          name: key,
          type: "scatter",
          symbolSize: 12,
          data: seriesData[key] ?? [],
        })),
        grid: { left: 60, right: 30, top: 60, bottom: 40 },
      };
    }

    return {
      toolbox,
      tooltip: { trigger: "axis" },
      legend: { data: yKeys, top: 0 },
      xAxis: {
        type: "category",
        data: categories,
        boundaryGap: chartType === "bar",
      },
      yAxis: { type: "value" },
      series: yKeys.map((key) => ({
        name: key,
        type: isArea ? "line" : chartType,
        smooth: isArea,
        areaStyle: isArea ? {} : undefined,
        data: seriesData[key] ?? [],
      })),
      grid: { left: 60, right: 30, top: 60, bottom: 40 },
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [rowData, effectiveXAxisKey, effectiveYAxisKeys, config?.chartType]);

  return (
    <Card
      size="small"
      title={`차트 · ${chartId}`}
      extra={
        onRemove && (
          <Tooltip title="차트 삭제">
            <Button
              type="text"
              size="small"
              icon={<CloseOutlined />}
              onClick={() => onRemove(chartId)}
            />
          </Tooltip>
        )
      }
    >
      <Space size={12} wrap style={{ marginBottom: 16 }}>
        <Space direction="vertical" size={4}>
          <Text type="secondary">X축</Text>
          <Select
            style={{ width: 160 }}
            value={effectiveXAxisKey}
            onChange={(value) => setXAxisKey(chartId, value)}
            options={xAxisOptions}
          />
        </Space>

        <Space direction="vertical" size={4}>
          <Text type="secondary">Y축 (시리즈)</Text>
          <Select
            mode="multiple"
            allowClear
            style={{ minWidth: 220 }}
            placeholder="표시할 항목 선택"
            value={effectiveYAxisKeys}
            onChange={(value) => setYAxisKeys(chartId, value)}
            options={yAxisOptions}
            maxTagCount="responsive"
            disabled={config?.chartType === "pie"}
          />
        </Space>

        <Space direction="vertical" size={4}>
          <Text type="secondary">차트 타입</Text>
          <Select
            style={{ width: 140 }}
            value={config?.chartType ?? "line"}
            onChange={(value) => setChartType(chartId, value)}
            options={CHART_TYPE_OPTIONS}
          />
        </Space>
      </Space>

      <ReactECharts
        ref={chartRef}
        option={option}
        style={{ height: 360, width: "100%" }}
        notMerge
        lazyUpdate
      />
    </Card>
  );
}
