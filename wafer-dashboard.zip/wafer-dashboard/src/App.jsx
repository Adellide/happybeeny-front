import React from "react";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { ConfigProvider } from "antd";

import Dashboard from "./components/Dashboard";

const queryClient = new QueryClient();

export default function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <ConfigProvider>
        <div style={{ padding: 24 }}>
          <Dashboard />
        </div>
      </ConfigProvider>
    </QueryClientProvider>
  );
}
