import { useTranslation } from 'react-i18next';
import './Page.css';

export default function Home() {
  const { t, i18n } = useTranslation();

  return (
    <div className="page fade-in">
      <div className="page-header">
        <span className="page-badge">{t('home.badge')}</span>
        <h1 className="page-title">{t('home.title')}</h1>
        <p className="page-subtitle">{t('home.subtitle')}</p>
      </div>
      <p className="page-desc">{t('home.description')}</p>

      <div className="card-grid">
        <div className="card">
          <span className="card-icon">🌐</span>
          <h3>react-i18next</h3>
          <p>업계 표준 다국어 라이브러리</p>
        </div>
        <div className="card">
          <span className="card-icon">⚡</span>
          <h3>React Router</h3>
          <p>Outlet 기반 레이아웃 라우팅</p>
        </div>
        <div className="card">
          <span className="card-icon">🎨</span>
          <h3>Vite + React</h3>
          <p>빠른 개발 환경</p>
        </div>
      </div>
    </div>
  );
}
