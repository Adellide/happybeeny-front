import { useTranslation } from 'react-i18next';
import './Page.css';

export default function Contact() {
  const { t } = useTranslation();

  const items = [
    { label: t('contact.email'), value: t('contact.emailValue'), icon: '✉' },
    { label: t('contact.phone'), value: t('contact.phoneValue'), icon: '☎' },
    { label: t('contact.address'), value: t('contact.addressValue'), icon: '◎' },
  ];

  return (
    <div className="page fade-in">
      <div className="page-header">
        <h1 className="page-title">{t('contact.title')}</h1>
        <p className="page-subtitle">{t('contact.subtitle')}</p>
      </div>

      <div className="contact-list">
        {items.map((item, i) => (
          <div key={i} className="contact-item">
            <span className="contact-icon">{item.icon}</span>
            <div>
              <p className="contact-label">{item.label}</p>
              <p className="contact-value">{item.value}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
