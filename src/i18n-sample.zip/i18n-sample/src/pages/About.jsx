import { useTranslation } from 'react-i18next';
import './Page.css';

export default function About() {
  const { t } = useTranslation();

  const features = [
    t('about.feature1'),
    t('about.feature2'),
    t('about.feature3'),
  ];

  return (
    <div className="page fade-in">
      <div className="page-header">
        <h1 className="page-title">{t('about.title')}</h1>
        <p className="page-subtitle">{t('about.subtitle')}</p>
      </div>
      <p className="page-desc">{t('about.description')}</p>

      <div className="feature-list">
        {features.map((f, i) => (
          <div key={i} className="feature-item">
            <span className="feature-num">0{i + 1}</span>
            <span>{f}</span>
          </div>
        ))}
      </div>
    </div>
  );
}
