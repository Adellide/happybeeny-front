import { NavLink, Outlet } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import './Menu.css';

export default function Menu() {
  const { t, i18n } = useTranslation();

  const handleLanguageChange = (e) => {
    i18n.changeLanguage(e.target.value);
  };

  return (
    <div className="layout">
      <aside className="sidebar">
        <div className="sidebar-logo">
          <span className="logo-icon">⬡</span>
          <span className="logo-text">i18n Demo</span>
        </div>

        <nav className="nav-links">
          <NavLink to="/" end className={({ isActive }) => isActive ? 'nav-item active' : 'nav-item'}>
            <span className="nav-icon">◈</span>
            {t('menu.home')}
          </NavLink>
          <NavLink to="/about" className={({ isActive }) => isActive ? 'nav-item active' : 'nav-item'}>
            <span className="nav-icon">◉</span>
            {t('menu.about')}
          </NavLink>
          <NavLink to="/contact" className={({ isActive }) => isActive ? 'nav-item active' : 'nav-item'}>
            <span className="nav-icon">◎</span>
            {t('menu.contact')}
          </NavLink>
        </nav>

        <div className="lang-section">
          <p className="lang-label">{t('menu.language')}</p>
          <label className={`radio-option ${i18n.language === 'ko' ? 'selected' : ''}`}>
            <input
              type="radio"
              name="language"
              value="ko"
              checked={i18n.language === 'ko'}
              onChange={handleLanguageChange}
            />
            <span className="radio-flag">🇰🇷</span>
            <span>한국어</span>
          </label>
          <label className={`radio-option ${i18n.language === 'en' ? 'selected' : ''}`}>
            <input
              type="radio"
              name="language"
              value="en"
              checked={i18n.language === 'en'}
              onChange={handleLanguageChange}
            />
            <span className="radio-flag">🇺🇸</span>
            <span>English</span>
          </label>
        </div>
      </aside>

      <main className="content">
        <Outlet />
      </main>
    </div>
  );
}
