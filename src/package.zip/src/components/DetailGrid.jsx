import React ,{ useState } from "react";

export default function DetailGrid({ columns, rows, onRowDoubleClick }) {
  const [selectedIdx, setSelectedIdx] = useState(null);

  return (
    <div className="dg-wrap">
      <table className="dg-table">
        <thead>
          <tr>
            {columns.map(col => (
              <th key={col.key} style={{ width: col.width, minWidth: col.width }}>
                {col.label}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {rows.map((row, i) => (
            <tr
              key={i}
              className={selectedIdx === i ? "selected" : ""}
              onClick={() => setSelectedIdx(i)}
              onDoubleClick={() => {
                setSelectedIdx(i);
                onRowDoubleClick(row);
              }}
            >
              {columns.map(col => (
                <td key={col.key} className={
                  col.key === "residual"
                    ? row[col.key] > 0 ? "pos" : "neg"
                    : ""
                }>
                  {typeof row[col.key] === "number"
                    ? row[col.key].toFixed(3)
                    : row[col.key]}
                </td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
