import React ,{ useEffect, useRef } from "react";

export default function RadioGroup({ label, options, value, onChange }) {
  return (
    <div className="rg-wrapper">
      <span className="rg-label">{label}</span>
      <div className="rg-options">
        {Object.entries(options).map(([key, opt]) => (
          <label key={key} className={`rg-item ${value === key ? "active" : ""}`}>
            <input
              type="radio"
              name="series-option"
              value={key}
              checked={value === key}
              onChange={() => onChange(key)}
            />
            <span
              className="rg-dot"
              style={{ background: opt.color }}
            />
            <span className="rg-text">{opt.label}</span>
          </label>
        ))}
      </div>
    </div>
  );
}
