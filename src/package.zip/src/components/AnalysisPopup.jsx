import React ,{ useState, useCallback } from "react";
import { generateScatterData, generateResidualData, calcRegression, SERIES_OPTIONS } from "../utils/chartUtils";
import DetailGrid from "./DetailGrid";
import MainScatterChart from "./charts/MainScatterChart";
import ResidualChart from "./charts/ResidualChart";
import DistributionChart from "./charts/DistributionChart";

// API 응답을 가정한 샘플 데이터
const SAMPLE_MAIN_DATA = [
  { 종류: "참치김밥", 상세종류: "참치김밥", 판매량: 1300, 날짜: 20260302, 비교: "정상" },
  { 종류: "쇠고기김밥", 상세종류: "쇠고기김밥", 판매량: 1600, 날짜: 20260303, 비교: "쇠고기김밥" },
  { 종류: "꼬마김밥", 상세종류: "꼬마김밥", 판매량: 1200, 날짜: 20260301, 비교: "정상" },
  { 종류: "쇠고기김밥", 상세종류: "쇠고기김밥", 판매량: 1100, 날짜: 20260305, 비교: "정상" }
];

function buildChartData(row, seriesOpt) {
  const raw = generateScatterData(80, 1.1, 10, 12);
  const reg = calcRegression(raw);
  const residuals = generateResidualData(raw, reg.slope, reg.intercept);
  const xDist = raw.map(([x]) => x);

  return { raw, reg, residuals, xDist, seriesOpt, row };
}

const DETAIL_COLUMNS = [
  { key: "subId", label: "#", width: 50 },
  { key: "group", label: "Group", width: 100 },
  { key: "xVal", label: "X", width: 90 },
  { key: "yVal", label: "Y", width: 90 },
  { key: "fitted", label: "Fitted", width: 90 },
  { key: "residual", label: "Residual", width: 90 },
  { key: "leverage", label: "Leverage", width: 90 },
  { key: "cooks", label: "Cook's D", width: 90 },
];

function buildDetailRows(raw, reg) {
  const n = raw.length;
  const xMean = raw.reduce((s, [x]) => s + x, 0) / n;
  const sxx = raw.reduce((s, [x]) => s + (x - xMean) ** 2, 0);
  const groups = ["A", "B", "C", "D"];

  return raw.map(([x, y], i) => {
    const fitted = parseFloat((reg.slope * x + reg.intercept).toFixed(3));
    const residual = parseFloat((y - fitted).toFixed(3));
    const leverage = parseFloat((1 / n + (x - xMean) ** 2 / sxx).toFixed(4));
    const cooks = parseFloat((residual ** 2 * leverage / (2 * (1 - leverage) ** 2)).toFixed(4));
    return {
      subId: i + 1,
      group: groups[i % 4],
      xVal: parseFloat(x.toFixed(2)),
      yVal: parseFloat(y.toFixed(2)),
      fitted,
      residual,
      leverage,
      cooks,
    };
  });
}

export default function AnalysisPopup({ rowData, onClose }) {
  const [seriesKey, setSeriesKey] = useState("default");
  const [chartData, setChartData] = useState(null);

  const handleSeriesChange = useCallback((key) => {
    setSeriesKey(key);
    // 라디오 변경 → 이미 그려진 차트의 시리즈 옵션만 업데이트
    if (chartData) {
      setChartData(prev => ({ ...prev, seriesOpt: SERIES_OPTIONS[key] }));
    }
  }, [chartData]);

  const handleDetailDoubleClick = useCallback((detailRow) => {
    // 하단 그리드 더블클릭 → 새 데이터로 차트 재드로우
    const data = buildChartData(rowData, SERIES_OPTIONS[seriesKey]);
    setChartData(data);
  }, [rowData, seriesKey]);

  // 팝업 첫 진입 시 차트 초기 그리기
  const [initialized, setInitialized] = useState(false);
  if (!initialized) {
    const data = buildChartData(rowData, SERIES_OPTIONS[seriesKey]);
    setChartData(data);
    setInitialized(true);
  }

  const detailRows = chartData ? buildDetailRows(chartData.raw, chartData.reg) : [];

  return (
    <div className="popup-overlay" onClick={(e) => e.target === e.currentTarget && onClose()}>
      <div className="popup-box">
        {/* 팝업 헤더 */}
        <div className="popup-header">
          <div className="popup-header-left">
            <span className="popup-tag">ANALYSIS</span>
            <span className="popup-title">{rowData?.name}</span>
            <span className="popup-meta">{rowData?.xVar} × {rowData?.yVar} &nbsp;·&nbsp; n={rowData?.samples}</span>
          </div>
          <button className="popup-close" onClick={onClose}>✕</button>
        </div>

        {/* 라디오 영역 */}
        <div className="popup-controls">
          <div className="rg-wrapper">
            <span className="rg-label">Series Style</span>
            <div className="rg-options">
              <label className={`rg-item ${seriesKey === "default" ? "active" : ""}`}>
                <input
                  type="radio"
                  name="series-option"
                  value="default"
                  checked={seriesKey === "default"}
                  onChange={() => handleSeriesChange("default")}
                />
                <span className="rg-dot" style={{ background: SERIES_OPTIONS["default"]?.color || "#3b82f6" }} />
                <span className="rg-text">기본</span>
              </label>
              <label className={`rg-item ${seriesKey === "special" ? "active" : ""}`}>
                <input
                  type="radio"
                  name="series-option"
                  value="special"
                  checked={seriesKey === "special"}
                  onChange={() => handleSeriesChange("special")}
                />
                <span className="rg-dot" style={{ background: SERIES_OPTIONS["special"]?.color || "#ef4444" }} />
                <span className="rg-text">특이</span>
              </label>
              <label className={`rg-item ${seriesKey === "compare" ? "active" : ""}`}>
                <input
                  type="radio"
                  name="series-option"
                  value="compare"
                  checked={seriesKey === "compare"}
                  onChange={() => handleSeriesChange("compare")}
                />
                <span className="rg-dot" style={{ background: SERIES_OPTIONS["compare"]?.color || "#10b981" }} />
                <span className="rg-text">비교</span>
              </label>
            </div>
          </div>
          {chartData && (
            <div className="r2-badge">
              R² = <strong>{chartData.reg.r2.toFixed(4)}</strong>
            </div>
          )}
        </div>

        {/* 차트 3개 */}
        <div className="popup-charts" style={{ display: "flex", gap: "20px", alignItems: "stretch", minHeight: "400px" }}>
          {chartData ? (
            <>
              {/* 왼쪽: 메인 차트 (2/3 영역 차지) */}
              <div style={{ flex: 2, display: "flex", flexDirection: "column", minWidth: 0 }}>
                <MainScatterChart data={SAMPLE_MAIN_DATA} viewMode={seriesKey} />
              </div>
              {/* 오른쪽: 보조 차트 2개 (1/3 영역 차지, 위아래 분할) */}
              <div style={{ flex: 1, display: "flex", flexDirection: "column", gap: "20px", minWidth: 0 }}>
                <div style={{ flex: 1, display: "flex", flexDirection: "column", minHeight: 0 }}>
                  <ResidualChart data={chartData} xLabel={rowData?.xVar} />
                </div>
                <div style={{ flex: 1, display: "flex", flexDirection: "column", minHeight: 0 }}>
                  <DistributionChart data={chartData} xLabel={rowData?.xVar} />
                </div>
              </div>
            </>
          ) : (
            <div className="chart-placeholder">하단 그리드를 더블클릭하여 차트를 그려주세요</div>
          )}
        </div>

        {/* 하단 그리드 */}
        <div className="popup-grid-area">
          <div className="popup-grid-header">
            <span>Detail Records</span>
            <span className="grid-hint">더블클릭하여 차트 갱신</span>
          </div>
          <DetailGrid
            columns={DETAIL_COLUMNS}
            rows={detailRows}
            onRowDoubleClick={handleDetailDoubleClick}
          />
        </div>
      </div>
    </div>
  );
}
