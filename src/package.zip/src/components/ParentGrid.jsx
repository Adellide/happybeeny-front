import React, { useState } from "react";

const COLUMNS = [
  { key: "id", label: "ID", width: 60 },
  { key: "name", label: "Dataset Name", width: 200 },
  { key: "xVar", label: "X Variable", width: 140 },
  { key: "yVar", label: "Y Variable", width: 140 },
  { key: "samples", label: "Samples", width: 100 },
  { key: "category", label: "Category", width: 120 },
  { key: "updatedAt", label: "Updated", width: 140 },
];

const MOCK_DATA = [
  { id: 1, name: "Temperature vs Sales", xVar: "Temperature (°C)", yVar: "Sales ($K)", samples: 120, category: "Retail", updatedAt: "2025-05-10" },
  { id: 2, name: "Height vs Weight", xVar: "Height (cm)", yVar: "Weight (kg)", samples: 250, category: "Health", updatedAt: "2025-05-08" },
  { id: 3, name: "Ad Spend vs Revenue", xVar: "Ad Spend ($K)", yVar: "Revenue ($K)", samples: 84, category: "Marketing", updatedAt: "2025-05-12" },
  { id: 4, name: "Study Hours vs Score", xVar: "Study Hours", yVar: "Test Score", samples: 180, category: "Education", updatedAt: "2025-05-06" },
  { id: 5, name: "Age vs Blood Pressure", xVar: "Age (years)", yVar: "BP (mmHg)", samples: 320, category: "Health", updatedAt: "2025-05-14" },
  { id: 6, name: "Humidity vs Comfort", xVar: "Humidity (%)", yVar: "Comfort Index", samples: 96, category: "Environment", updatedAt: "2025-05-11" },
  { id: 7, name: "CPU vs Latency", xVar: "CPU Usage (%)", yVar: "Latency (ms)", samples: 500, category: "IT", updatedAt: "2025-05-09" },
  { id: 8, name: "Income vs Expenditure", xVar: "Income ($K)", yVar: "Expenditure ($K)", samples: 210, category: "Finance", updatedAt: "2025-05-13" },
];

export default function ParentGrid({ onRowDoubleClick }) {
  const [selectedId, setSelectedId] = useState(null);
  const [sortKey, setSortKey] = useState(null);
  const [sortDir, setSortDir] = useState("asc");

  const handleSort = (key) => {
    if (sortKey === key) setSortDir(d => d === "asc" ? "desc" : "asc");
    else { setSortKey(key); setSortDir("asc"); }
  };

  const sorted = [...MOCK_DATA].sort((a, b) => {
    if (!sortKey) return 0;
    const av = a[sortKey]; const bv = b[sortKey];
    const cmp = typeof av === "number" ? av - bv : String(av).localeCompare(String(bv));
    return sortDir === "asc" ? cmp : -cmp;
  });

  return (
    <div className="pg-wrapper">
      <div className="pg-header">
        <span className="pg-title">Dataset Registry</span>
        <span className="pg-hint">더블클릭하여 상관분석 팝업 열기</span>
      </div>
      <div className="pg-table-wrap">
        <table className="pg-table">
          <thead>
            <tr>
              {COLUMNS.map(col => (
                <th
                  key={col.key}
                  style={{ width: col.width, minWidth: col.width }}
                  className={sortKey === col.key ? "sorted" : ""}
                  onClick={() => handleSort(col.key)}
                >
                  {col.label}
                  {sortKey === col.key && (
                    <span className="sort-icon">{sortDir === "asc" ? " ↑" : " ↓"}</span>
                  )}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {sorted.map(row => (
              <tr
                key={row.id}
                className={selectedId === row.id ? "selected" : ""}
                onClick={() => setSelectedId(row.id)}
                onDoubleClick={() => {
                  setSelectedId(row.id);
                  onRowDoubleClick(row);
                }}
              >
                {COLUMNS.map(col => (
                  <td key={col.key}>
                    {col.key === "category"
                      ? <span className={`badge badge-${row.category.toLowerCase()}`}>{row.category}</span>
                      : row[col.key]}
                  </td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <div className="pg-footer">
        <span>{MOCK_DATA.length} records &nbsp;·&nbsp; 더블클릭으로 분석 시작</span>
      </div>
    </div>
  );
}
