import React ,{ useEffect, useRef } from "react";
import * as echarts from "echarts";


export default function MainScatterChart({ data, viewMode = "default", xLabel = "날짜", yLabel = "판매량" }) {
  const ref = useRef(null);
  const chartRef = useRef(null);

  useEffect(() => {
    if (!ref.current) return;
    chartRef.current = echarts.init(ref.current, null, { 
      renderer: "canvas",
      width: ref.current.clientWidth === 0 ? 500 : undefined,
      height: ref.current.clientHeight === 0 ? 300 : undefined,
    });
    return () => chartRef.current?.dispose();
  }, []);

  useEffect(() => {
    if (!chartRef.current || !data || !Array.isArray(data)) return;

    // 라디오 버튼 상태에 따라 그룹화할 키(종류 vs 상세종류 vs 비교) 결정
    const groupKey = viewMode === "default" ? "종류" : viewMode === "special" ? "상세종류" : "비교";

    // X축에 표시할 고유 날짜 추출 및 오름차순 정렬
    const uniqueDates = Array.from(new Set(data.map((item) => String(item.날짜)))).sort();

    // 데이터를 groupKey 기준으로 분류
    const groupedData = {};
    data.forEach((item) => {
      let key = item[groupKey];

      // 그룹키가 '비교'이고, 값이 '정상'이 아니면 뒤에 '_이상'을 붙여줌 (예: '쇠고기김밥_이상')
      if (groupKey === "비교" && key !== "정상") {
        key = `${key}_이상`;
      }

      if (!groupedData[key]) groupedData[key] = [];
      // [x축 값, y축 값, 툴팁용 원본 객체]
      groupedData[key].push([String(item.날짜), item.판매량, item]);
    });

    // 각 그룹별로 ECharts Series 생성
    const series = Object.keys(groupedData).map((key) => ({
      name: key,
      type: "scatter",
      data: groupedData[key],
      symbolSize: 12,
      emphasis: { focus: "series" },
    }));

    // X축(날짜)이 카테고리이므로 인덱스(0, 1, 2...)로 변환하여 전체 데이터 대상 선형 회귀식 계산
    const dateToIndex = {};
    uniqueDates.forEach((date, i) => (dateToIndex[date] = i));

    const n = data.length;
    let xSum = 0, ySum = 0, xySum = 0, xxSum = 0;
    data.forEach((item) => {
      const x = dateToIndex[String(item.날짜)];
      const y = item.판매량;
      xSum += x;
      ySum += y;
      xySum += x * y;
      xxSum += x * x;
    });

    const yMean = ySum / n;
    const denominator = n * xxSum - xSum * xSum;
    let slope = 0, intercept = yMean || 0, r2 = 1;

    if (denominator !== 0) {
      slope = (n * xySum - xSum * ySum) / denominator;
      intercept = (ySum - slope * xSum) / n;

      let ssTot = 0, ssRes = 0;
      data.forEach((item) => {
        const x = dateToIndex[String(item.날짜)];
        const y = item.판매량;
        ssTot += (y - yMean) ** 2;
        const predicted = slope * x + intercept;
        ssRes += (y - predicted) ** 2;
      });
      r2 = ssTot === 0 ? 1 : 1 - (ssRes / ssTot);
    }

    // 회귀선 데이터 생성 (각 날짜 인덱스에 따른 Y 예측값)
    const regressionLineData = uniqueDates.map((date, index) => [
      date,
      parseFloat((slope * index + intercept).toFixed(2))
    ]);

    // 계산된 회귀선을 ECharts 시리즈에 추가
    series.push({
      name: "회귀선",
      type: "line",
      data: regressionLineData,
      lineStyle: { color: "#ff6b6b", width: 2, type: "dashed" },
      itemStyle: { color: "#ff6b6b" },
      symbol: "none",
      smooth: false,
      z: 10,
    });

    const option = {
      backgroundColor: "transparent",
      animation: true,
      animationDuration: 600,
      grid: { top: 40, right: 120, bottom: 50, left: 60 }, // 우측에 범례(legend) 영역 확보
      tooltip: {
        trigger: "item",
        backgroundColor: "#1a1e2a",
        borderColor: "#252a38",
        textStyle: { color: "#e8eaf0", fontSize: 13, fontFamily: "Space Mono" },
        formatter: (p) => {
          if (p.seriesName === "회귀선") {
            return `<b>회귀선</b><br/>날짜: <b>${p.data[0]}</b><br/>예측 판매량: <b>${p.data[1]}</b>`;
          }
          const item = p.data[2]; // 원본 데이터 추출
          return `<b>${p.seriesName}</b><br/>` +
                 `날짜: <b>${item.날짜}</b><br/>` +
                 `판매량: <b>${item.판매량}</b><br/>` +
                 `비교: <b>${item.비교}</b>`;
        },
      },
      legend: {
        type: "scroll",
        orient: "vertical",
        right: 10,
        top: 40,
        textStyle: { color: "#e8eaf0" },
        data: series.map((s) => s.name).filter((name) => name !== "회귀선"),
      },
      xAxis: {
        type: "category",
        name: xLabel,
        nameLocation: "middle",
        nameGap: 30,
        data: uniqueDates,
        nameTextStyle: { color: "#7a8099", fontSize: 11, fontFamily: "Space Mono" },
        axisLine: { lineStyle: { color: "#252a38" } },
        splitLine: { show: false }, // 카테고리 축에서는 보통 숨김
        axisLabel: { color: "#7a8099", fontSize: 10, fontFamily: "Space Mono" },
      },
      yAxis: {
        type: "value",
        name: yLabel,
        nameTextStyle: { color: "#7a8099", fontSize: 11, fontFamily: "Space Mono" },
        axisLine: { lineStyle: { color: "#252a38" } },
        splitLine: { lineStyle: { color: "#1a1e2a" } },
        axisLabel: { color: "#7a8099", fontSize: 10, fontFamily: "Space Mono" },
      },
      graphic: [
        {
          type: "text",
          left: 70,
          top: 8,
          style: {
            text: `R² = ${r2.toFixed(4)}   y = ${slope.toFixed(2)}x + ${intercept.toFixed(2)}`,
            fill: "#6c63ff",
            fontSize: 12,
            fontFamily: "Space Mono",
            fontWeight: "bold",
          },
        },
      ],
      series: series,
    };

    chartRef.current.setOption(option, { notMerge: true });
  }, [data, viewMode, xLabel, yLabel]);

  useEffect(() => {
    if (!ref.current) return;
    const observer = new ResizeObserver(() => {
      chartRef.current?.resize();
    });
    observer.observe(ref.current);
    return () => observer.disconnect();
  }, []);

  return (
    <div className="chart-cell chart-main">
      <div className="chart-label">판매량 분석 산점도</div>
      <div ref={ref} className="chart-canvas" />
    </div>
  );
}
