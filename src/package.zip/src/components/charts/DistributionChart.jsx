import React ,{ useEffect, useRef } from "react";
import * as echarts from "echarts";

export default function DistributionChart({ data, xLabel = "X" }) {
  const ref = useRef(null);
  const chartRef = useRef(null);

  useEffect(() => {
    if (!ref.current) return;
    chartRef.current = echarts.init(ref.current, null, { 
      renderer: "canvas",
      width: ref.current.clientWidth === 0 ? 500 : undefined,
      height: ref.current.clientHeight === 0 ? 300 : undefined,
    });
    return () => chartRef.current?.dispose();
  }, []);

  useEffect(() => {
    if (!chartRef.current || !data) return;
    const { raw, seriesOpt = {} } = data;

    // Q-Q plot: X 분포 vs 정규분포 이론값
    const xVals = raw.map(([x]) => x).sort((a, b) => a - b);
    const n = xVals.length;
    const mean = xVals.reduce((s, v) => s + v, 0) / n;
    const std = Math.sqrt(xVals.reduce((s, v) => s + (v - mean) ** 2, 0) / n);

    // Theoretical quantiles (normal)
    function invNorm(p) {
      // Beasley-Springer approximation
      const a = [0, -3.969683028665376e+01, 2.209460984245205e+02, -2.759285104469687e+02,
        1.383577518672690e+02, -3.066479806614716e+01, 2.506628277459239e+00];
      const b = [0, -5.447609879822406e+01, 1.615858368580409e+02, -1.556989798598866e+02,
        6.680131188771972e+01, -1.328068155288572e+01];
      const c = [0, -7.784894002430293e-03, -3.223964580411365e-01, -2.400758277161838e+00,
        -2.549732539343734e+00, 4.374664141464968e+00, 2.938163982698783e+00];
      const d = [0, 7.784695709041462e-03, 3.224671290700398e-01, 2.445134137142996e+00, 3.754408661907416e+00];
      const pLow = 0.02425; const pHigh = 1 - pLow;
      if (p < pLow) {
        const q = Math.sqrt(-2 * Math.log(p));
        return (((((c[1]*q+c[2])*q+c[3])*q+c[4])*q+c[5])*q+c[6]) /
               ((((d[1]*q+d[2])*q+d[3])*q+d[4])*q+1);
      } else if (p <= pHigh) {
        const q = p - 0.5; const r = q * q;
        return (((((a[1]*r+a[2])*r+a[3])*r+a[4])*r+a[5])*r+a[6])*q /
               (((((b[1]*r+b[2])*r+b[3])*r+b[4])*r+b[5])*r+1);
      } else {
        const q = Math.sqrt(-2 * Math.log(1 - p));
        return -(((((c[1]*q+c[2])*q+c[3])*q+c[4])*q+c[5])*q+c[6]) /
                ((((d[1]*q+d[2])*q+d[3])*q+d[4])*q+1);
      }
    }

    const qqData = xVals.map((x, i) => {
      const p = (i + 0.5) / n;
      const theoretical = mean + std * invNorm(p);
      return [parseFloat(theoretical.toFixed(2)), parseFloat(x.toFixed(2))];
    });

    // 45도 대각선 (이상적 정규)
    const minT = qqData[0][0]; const maxT = qqData[qqData.length - 1][0];
    const diagLine = [[minT, minT], [maxT, maxT]];

    const option = {
      backgroundColor: "transparent",
      animation: true,
      animationDuration: 600,
      grid: { top: 40, right: 16, bottom: 50, left: 54 },
      tooltip: {
        trigger: "item",
        backgroundColor: "#1a1e2a",
        borderColor: "#252a38",
        textStyle: { color: "#e8eaf0", fontSize: 11, fontFamily: "Space Mono" },
        formatter: (p) => {
          if (p.seriesIndex === 0)
            return `Theoretical: <b>${p.data[0]}</b><br/>Sample: <b>${p.data[1]}</b>`;
          return "Reference line";
        },
      },
      xAxis: {
        type: "value",
        name: "Theoretical",
        nameLocation: "end",
        nameTextStyle: { color: "#7a8099", fontSize: 10, fontFamily: "Space Mono" },
        axisLine: { lineStyle: { color: "#252a38" } },
        splitLine: { lineStyle: { color: "#1a1e2a" } },
        axisLabel: { color: "#7a8099", fontSize: 9, fontFamily: "Space Mono" },
      },
      yAxis: {
        type: "value",
        name: "Sample",
        nameTextStyle: { color: "#7a8099", fontSize: 10, fontFamily: "Space Mono" },
        axisLine: { lineStyle: { color: "#252a38" } },
        splitLine: { lineStyle: { color: "#1a1e2a" } },
        axisLabel: { color: "#7a8099", fontSize: 9, fontFamily: "Space Mono" },
      },
      series: [
        {
          name: "Q-Q",
          type: "scatter",
          data: qqData,
          symbolSize: seriesOpt.symbolSize || 12,
          itemStyle: { 
            color: seriesOpt.color || "#3b82f6", 
            opacity: seriesOpt.opacity || 0.8 
          },
        },
        {
          name: "Reference",
          type: "line",
          data: diagLine,
          lineStyle: { color: "#6c63ff", width: 1.5, type: "dashed" },
          symbol: "none",
          itemStyle: { color: "#6c63ff" },
        },
      ],
    };

    chartRef.current.setOption(option, { notMerge: true });
  }, [data, xLabel]);

  useEffect(() => {
    if (!ref.current) return;
    const observer = new ResizeObserver(() => {
      chartRef.current?.resize();
    });
    observer.observe(ref.current);
    return () => observer.disconnect();
  }, []);

  return (
    <div className="chart-cell">
      <div className="chart-label">Q-Q Plot (Normality)</div>
      <div ref={ref} className="chart-canvas" />
    </div>
  );
}
