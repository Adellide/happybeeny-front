import React, { useMemo } from "react";
import ReactECharts from "echarts-for-react";

export default function ResidualChart({ data, xLabel = "X" }) {
  // data나 xLabel이 변경될 때만 option 객체를 재생성하여 성능 최적화
  const option = useMemo(() => {
    if (!data) return {};
    const { residuals, seriesOpt = {} } = data;

    return {
      backgroundColor: "transparent",
      animation: true,
      animationDuration: 600,
      grid: { top: 40, right: 16, bottom: 50, left: 54 },
      tooltip: {
        trigger: "item",
        backgroundColor: "#1a1e2a",
        borderColor: "#252a38",
        textStyle: { color: "#e8eaf0", fontSize: 11, fontFamily: "Space Mono" },
        formatter: (p) => `${xLabel}: <b>${p.data[0]}</b><br/>Residual: <b>${p.data[1]}</b>`,
      },
      xAxis: {
        type: "value",
        name: xLabel,
        nameLocation: "end",
        nameTextStyle: { color: "#7a8099", fontSize: 10, fontFamily: "Space Mono" },
        axisLine: { lineStyle: { color: "#252a38" } },
        splitLine: { lineStyle: { color: "#1a1e2a" } },
        axisLabel: { color: "#7a8099", fontSize: 9, fontFamily: "Space Mono" },
      },
      yAxis: {
        type: "value",
        name: "Residual",
        nameTextStyle: { color: "#7a8099", fontSize: 10, fontFamily: "Space Mono" },
        axisLine: { lineStyle: { color: "#252a38" } },
        splitLine: { lineStyle: { color: "#1a1e2a", type: "dashed" } },
        axisLabel: { color: "#7a8099", fontSize: 9, fontFamily: "Space Mono" },
      },
      markLine: {},
      series: [
        {
          name: "Residual",
          type: "scatter",
          data: residuals,
          symbolSize: seriesOpt.symbolSize || 12,
          itemStyle: {
            color: (params) => params.data[1] >= 0 ? "#4fffb0" : "#ff6b6b",
            opacity: seriesOpt.opacity || 0.8,
          },
          markLine: {
            silent: true,
            lineStyle: { color: "#7a8099", type: "dashed", width: 1 },
            data: [{ yAxis: 0 }],
            label: { show: false },
          },
        },
      ],
    };
  }, [data, xLabel]);

  return (
    <div className="chart-cell">
      <div className="chart-label">Residual vs Fitted</div>
      {data ? (
        <ReactECharts
          option={option}
          className="chart-canvas"
          style={{ height: "100%", width: "100%" }}
          notMerge={true}
        />
      ) : (
        <div className="chart-canvas" />
      )}
    </div>
  );
}
