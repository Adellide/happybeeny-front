/**
 * 산점도 데이터 생성 유틸리티
 * - 상관관계 강도에 따라 scatter 데이터 생성
 * - 회귀선(OLS) 계산
 * - R² 계산
 * n = 60 (데이터 개수): 점이 60개 정도면 차트가 너무 휑해 보이지도 않고, 반대로 너무 빽빽해서 뭉쳐 보이지도 않는 아주 적당한 개수입니다.
slope = 1.2, intercept = 5 (기울기와 y절편): 점들이 뚜렷하게 우상향하는(양의 상관관계) 선형 패턴을 그리도록 만듭니다.
noise = 8 (노이즈/오차): 모든 점이 완벽하게 일직선 위에만 있으면 실제 데이터처럼 보이지 않고 부자연스럽습니다. 이 값을 주어 위아래로 점들을 적당히 흩뿌려지게(분산되게) 만들어 진짜 통계 데이터 같은 느낌을 줍니다.
 */

export function generateScatterData(n = 60, slope = 1.2, intercept = 5, noise = 8) {
  const data = [];
  for (let i = 0; i < n; i++) {
    const x = Math.random() * 80 + 10;
    const y = slope * x + intercept + (Math.random() - 0.5) * noise * 2;
    data.push([parseFloat(x.toFixed(2)), parseFloat(y.toFixed(2))]);
  }
  return data;
}

export function generateResidualData(rawData, slope, intercept) {
  return rawData.map(([x, y]) => {
    const fitted = slope * x + intercept;
    return [parseFloat(x.toFixed(2)), parseFloat((y - fitted).toFixed(2))];
  });
}

export function calcRegression(data) {
  const n = data.length;
  const sumX = data.reduce((s, [x]) => s + x, 0);
  const sumY = data.reduce((s, [, y]) => s + y, 0);
  const sumXY = data.reduce((s, [x, y]) => s + x * y, 0);
  const sumX2 = data.reduce((s, [x]) => s + x * x, 0);

  const slope = (n * sumXY - sumX * sumY) / (n * sumX2 - sumX * sumX);
  const intercept = (sumY - slope * sumX) / n;

  const meanY = sumY / n;
  const ssTot = data.reduce((s, [, y]) => s + (y - meanY) ** 2, 0);
  const ssRes = data.reduce((s, [x, y]) => s + (y - (slope * x + intercept)) ** 2, 0);
  const r2 = 1 - ssRes / ssTot;

  const xs = data.map(([x]) => x);
  const minX = Math.min(...xs);
  const maxX = Math.max(...xs);
  const line = [
    [parseFloat(minX.toFixed(2)), parseFloat((slope * minX + intercept).toFixed(2))],
    [parseFloat(maxX.toFixed(2)), parseFloat((slope * maxX + intercept).toFixed(2))],
  ];

  return { slope, intercept, r2, line };
}

/** 라디오 옵션별 시리즈 설정 */
export const SERIES_OPTIONS = {
  default: {
    label: "기본",
    symbolSize: 6,
    opacity: 0.75,
    color: "#4fffb0",
  },
  large: {
    label: "크게",
    symbolSize: 10,
    opacity: 0.65,
    color: "#6c63ff",
  },
  highlight: {
    label: "강조",
    symbolSize: 7,
    opacity: 0.9,
    color: "#ff6b6b",
  },
};
