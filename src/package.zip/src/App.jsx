import React, { useState } from "react";
import ParentGrid from "./components/ParentGrid";
import AnalysisPopup from "./components/AnalysisPopup";
import CombinedAnalysisPopup from "./components/CombinedAnalysisPopup";
export default function App() {
  const [popupOpen, setPopupOpen] = useState(false);
  const [selectedRow, setSelectedRow] = useState(null);

  const handleRowDoubleClick = (row) => {
    setSelectedRow(row);
    setPopupOpen(true);
  };

  return (
    <div style={{ fontFamily: "sans-serif", padding: "20px", color: "#333" }}>
      <header style={{ marginBottom: "20px", paddingBottom: "10px", borderBottom: "1px solid #ccc" }}>
        <span style={{ fontSize: "24px", fontWeight: "bold", marginRight: "10px" }}>Statistical Analysis Dashboard</span>
        <span style={{ fontSize: "14px", color: "#666" }}>Correlation &amp; Regression Explorer</span>
      </header>
      <main style={{ padding: "10px", background: "#f8f9fa", borderRadius: "8px" }}>
        <ParentGrid onRowDoubleClick={handleRowDoubleClick} />
      </main>
      {popupOpen && (
        <>
        <AnalysisPopup
          rowData={selectedRow}
          onClose={() => setPopupOpen(false)}
        />
        <CombinedAnalysisPopup
          rowData={selectedRow}
          onClose={() => setPopupOpen(false)}
        />
        </>
      )}
    </div>
  );
}
