import React, { useState } from "react";
import { Select, Checkbox } from "antd";

const COLUMNS = [
  { key: "id", label: "ID", width: 60 },
  { key: "name", label: "Dataset Name", width: 200 },
  { key: "xVar", label: "X Variable", width: 140 },
  { key: "yVar", label: "Y Variable", width: 140 },
  { key: "samples", label: "Samples", width: 100 },
  { key: "category", label: "Category", width: 120 },
  { key: "updatedAt", label: "Updated", width: 140 },
];

const MOCK_DATA = [
  { id: 1, name: "Temperature vs Sales", xVar: "Temperature (°C)", yVar: "Sales ($K)", samples: 120, category: "Retail", updatedAt: "2025-05-10" },
  { id: 2, name: "Height vs Weight", xVar: "Height (cm)", yVar: "Weight (kg)", samples: 250, category: "Health", updatedAt: "2025-05-08" },
  { id: 3, name: "Ad Spend vs Revenue", xVar: "Ad Spend ($K)", yVar: "Revenue ($K)", samples: 84, category: "Marketing", updatedAt: "2025-05-12" },
  { id: 4, name: "Study Hours vs Score", xVar: "Study Hours", yVar: "Test Score", samples: 180, category: "Education", updatedAt: "2025-05-06" },
  { id: 5, name: "Age vs Blood Pressure", xVar: "Age (years)", yVar: "BP (mmHg)", samples: 320, category: "Health", updatedAt: "2025-05-14" },
  { id: 6, name: "Humidity vs Comfort", xVar: "Humidity (%)", yVar: "Comfort Index", samples: 96, category: "Environment", updatedAt: "2025-05-11" },
  { id: 7, name: "CPU vs Latency", xVar: "CPU Usage (%)", yVar: "Latency (ms)", samples: 500, category: "IT", updatedAt: "2025-05-09" },
  { id: 8, name: "Income vs Expenditure", xVar: "Income ($K)", yVar: "Expenditure ($K)", samples: 210, category: "Finance", updatedAt: "2025-05-13" },
];

export default function ParentGrid({ onRowDoubleClick }) {
  const [selectedId, setSelectedId] = useState(null);
  const [sortKey, setSortKey] = useState(null);
  const [sortDir, setSortDir] = useState("asc");
  // 다중 선택을 위해 초기값을 배열로 설정합니다.
  const [visibleColumn, setVisibleColumn] = useState(["category", "updatedAt"]);

  const handleSort = (key) => {
    if (sortKey === key) setSortDir(d => d === "asc" ? "desc" : "asc");
    else { setSortKey(key); setSortDir("asc"); }
  };

  const sorted = [...MOCK_DATA].sort((a, b) => {
    if (!sortKey) return 0;
    const av = a[sortKey]; const bv = b[sortKey];
    const cmp = typeof av === "number" ? av - bv : String(av).localeCompare(String(bv));
    return sortDir === "asc" ? cmp : -cmp;
  });

  // 선택된 셀렉트박스 배열 값에 따라 표시할 컬럼 필터링
  const visibleColumns = COLUMNS.filter(col => {
    if (col.key === "category" && !visibleColumn.includes("category")) return false;
    if (col.key === "updatedAt" && !visibleColumn.includes("updatedAt")) return false;
    return true;
  });

  return (
    <div className="pg-wrapper">
      <div className="pg-header">
        <div style={{ display: "flex", alignItems: "center", gap: "16px" }}>
          <span className="pg-title">Dataset Registry</span>
          <Select
            mode="multiple"
            value={visibleColumn}
            onChange={(values) => setVisibleColumn(values)}
            style={{ minWidth: "220px" }}
            placeholder="표시할 컬럼을 선택하세요"
            optionLabelProp="label"
            maxTagCount="responsive"
          >
            <Select.Option value="category" label="Category">
              {/* pointerEvents: 'none' 을 추가하여 옵션 클릭시 이벤트 충돌을 방지합니다 */}
              <Checkbox checked={visibleColumn.includes("category")} style={{ pointerEvents: "none", marginRight: 8 }} />
              Category 컬럼
            </Select.Option>
            <Select.Option value="updatedAt" label="Updated">
              <Checkbox checked={visibleColumn.includes("updatedAt")} style={{ pointerEvents: "none", marginRight: 8 }} />
              Updated 컬럼
            </Select.Option>
          </Select>
        </div>
        <span className="pg-hint">더블클릭하여 상관분석 팝업 열기</span>
      </div>
      <div className="pg-table-wrap">
        <table className="pg-table">
          <thead>
            <tr>
              {visibleColumns.map(col => (
                <th
                  key={col.key}
                  style={{ width: col.width, minWidth: col.width }}
                  className={sortKey === col.key ? "sorted" : ""}
                  onClick={() => handleSort(col.key)}
                >
                  {col.label}
                  {sortKey === col.key && (
                    <span className="sort-icon">{sortDir === "asc" ? " ↑" : " ↓"}</span>
                  )}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {sorted.map(row => (
              <tr
                key={row.id}
                className={selectedId === row.id ? "selected" : ""}
                onClick={() => setSelectedId(row.id)}
                onDoubleClick={() => {
                  setSelectedId(row.id);
                  onRowDoubleClick(row);
                }}
              >
                {visibleColumns.map(col => (
                  <td key={col.key}>
                    {col.key === "category"
                      ? <span className={`badge badge-${row.category.toLowerCase()}`}>{row.category}</span>
                      : row[col.key]}
                  </td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <div className="pg-footer">
        <span>{MOCK_DATA.length} records &nbsp;·&nbsp; 더블클릭으로 분석 시작</span>
      </div>
    </div>
  );
}
