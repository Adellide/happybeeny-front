import React, { useState, useMemo, useCallback } from "react";
import ReactECharts from "echarts-for-react";

const DIM_OPACITY = 0.15;
const MONTHS = ["1월", "2월", "3월", "4월", "5월", "6월", "7월"];

function makeName(i) {
  if (i < 26) return `상품 ${String.fromCharCode(65 + i)}`;
  return `상품 ${String.fromCharCode(65 + (i - 26))}${String.fromCharCode(65 + (i - 26))}`;
}

function randData(seed) {
  return MONTHS.map((_, j) => Math.floor(((seed * 7 + j * 13) % 17) * 10 + 30));
}

const RAW_SERIES = {
  chart1: Array.from({ length: 52 }, (_, i) => ({ name: makeName(i), data: randData(i + 1) })),
  chart2: Array.from({ length: 52 }, (_, i) => ({ name: makeName(i), data: randData(i + 53) })),
  chart3: Array.from({ length: 52 }, (_, i) => ({ name: makeName(i), data: randData(i + 105) })),
};

// option.series 에서 name 추출
const SERIES_NAMES = RAW_SERIES.chart1.map((s) => s.name);

// ECharts 기본 팔레트 (10색 순환)
const ECHARTS_COLORS = [
  "#5470c6","#91cc75","#fac858","#ee6666","#73c0de",
  "#3ba272","#fc8452","#9a60b4","#ea7ccc","#5470c6",
];
function getColor(i) {
  return ECHARTS_COLORS[i % ECHARTS_COLORS.length];
}

function buildSeries(rawList, highlighted) {
  return rawList.map((s) => ({
    name: s.name,
    type: "bar",
    data: s.data,
    itemStyle: {
      opacity: highlighted === null || s.name === highlighted ? 1 : DIM_OPACITY,
    },
  }));
}

const COMMON = {
  tooltip: { trigger: "axis", axisPointer: { type: "shadow" } },
  xAxis: { type: "category", data: MONTHS },
  yAxis: { type: "value" },
};

export default function SyncBarCharts() {
  const [highlighted, setHighlighted] = useState(null);

  const handleLegendClick = useCallback((name) => {
    setHighlighted((prev) => (prev === name ? null : name));
  }, []);

  const option1 = useMemo(() => ({
    ...COMMON,
    title: { text: "매출 분석 (Chart 1)", left: "center" },
    grid: { top: 50 },
    series: buildSeries(RAW_SERIES.chart1, highlighted),
  }), [highlighted]);

  const option2 = useMemo(() => ({
    ...COMMON,
    title: { text: "이익률 분석 (Chart 2)", left: "center" },
    grid: { top: 50 },
    series: buildSeries(RAW_SERIES.chart2, highlighted),
  }), [highlighted]);

  const option3 = useMemo(() => ({
    ...COMMON,
    title: { text: "방문자 수 (Chart 3)", left: "center" },
    grid: { top: 50 },
    series: buildSeries(RAW_SERIES.chart3, highlighted),
  }), [highlighted]);

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: "1rem", padding: "1rem" }}>

      {/* 공통 Legend — scroll 가능한 버튼 목록 */}
      <div style={{
        border: "1px solid #ddd",
        borderRadius: "8px",
        background: "#fafafa",
        padding: "8px 16px",
      }}>
        <div style={{
          display: "flex",
          flexWrap: "wrap",
          gap: "4px 8px",
          maxHeight: 80,
          overflowY: "auto",
        }}>
          {SERIES_NAMES.map((name, i) => {
            const isActive = highlighted === null || highlighted === name;
            return (
              <button
                key={name}
                onClick={() => handleLegendClick(name)}
                style={{
                  display: "flex",
                  alignItems: "center",
                  gap: "5px",
                  padding: "3px 8px",
                  border: "none",
                  background: "transparent",
                  cursor: "pointer",
                  opacity: isActive ? 1 : 0.3,
                  transition: "opacity 0.2s",
                  fontSize: "12px",
                  color: "#333",
                  whiteSpace: "nowrap",
                }}
              >
                <span style={{
                  display: "inline-block",
                  width: 12,
                  height: 12,
                  borderRadius: 2,
                  background: getColor(i),
                  flexShrink: 0,
                }} />
                {name}
              </button>
            );
          })}
        </div>
      </div>

      {/* 3개 차트 */}
      <div style={{ display: "flex", flexDirection: "row", gap: "1rem" }}>
        <div style={{ flex: 1, border: "1px solid #ddd", padding: "1rem", borderRadius: "8px" }}>
          <ReactECharts option={option1} style={{ height: 300, width: "100%" }} notMerge />
        </div>
        <div style={{ flex: 1, border: "1px solid #ddd", padding: "1rem", borderRadius: "8px" }}>
          <ReactECharts option={option2} style={{ height: 300, width: "100%" }} notMerge />
        </div>
        <div style={{ flex: 1, border: "1px solid #ddd", padding: "1rem", borderRadius: "8px" }}>
          <ReactECharts option={option3} style={{ height: 300, width: "100%" }} notMerge />
        </div>
      </div>

    </div>
  );
}