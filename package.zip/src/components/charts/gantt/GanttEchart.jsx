import React, { useEffect, useRef } from "react";
import * as echarts from "echarts";
import { getGanttOption } from "./getOption";
import "./gantt.css";

const ROW_HEIGHT = 40;
const HEADER_HEIGHT = 56;

const GanttEchart = ({  }) => {
  const chartRef = useRef(null);
const tasks = [
  { id: "Task 1", head: "H1", name: "요구사항 분석", x: 10, y: 10, start: 0.0, end: 0.8 },
];
  useEffect(() => {
    const chart = echarts.init(chartRef.current);
    chart.setOption(getGanttOption(tasks, ROW_HEIGHT, HEADER_HEIGHT));

    const handleResize = () => chart.resize();
    window.addEventListener("resize", handleResize);
    return () => {
      window.removeEventListener("resize", handleResize);
      chart.dispose();
    };
  }, [tasks]);

  const chartHeight = HEADER_HEIGHT + tasks.length * ROW_HEIGHT + 20;

  return (
    <div className="gantt-wrapper">
      <div className="gantt-left">
        <table className="gantt-table">
          <thead>
            <tr>
              <th rowSpan={2}>기본ID</th>
              <th rowSpan={2}>Head</th>
              <th rowSpan={2}>Base Nm</th>
              <th colSpan={2}>DY</th>
            </tr>
            <tr>
              <th>X</th>
              <th>Y</th>
            </tr>
          </thead>
          <tbody>
            {tasks.map((task) => (
              <tr key={task.id}>
                <td>{task.id}</td>
                <td>{task.head}</td>
                <td>{task.name}</td>
                <td>{task.x}</td>
                <td>{task.y}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <div
        className="gantt-right"
        ref={chartRef}
        style={{ height: chartHeight }}
      />
    </div>
  );
};

export default GanttEchart;