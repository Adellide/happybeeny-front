export const getGanttOption = (tasks, rowHeight, headerHeight) => {
  const taskNames = tasks.map((t) => t.name);

  return {
    grid: {
      top: headerHeight,
      left: 0,
      right: 16,
      bottom: 0,
    },
    xAxis: {
      type: "value",
      min: 0,
      max: 1,
      interval: 0.2,
      position: "top",
      offset: -(headerHeight / 2),
      axisLabel: {
        formatter: (val) => val.toFixed(1),
        fontSize: 11,
        margin: 6,
      },
      splitLine: { show: true, lineStyle: { color: "#e0e0e0" } },
      axisLine: { show: false },
      axisTick: { show: true, length: 4 },
    },
    yAxis: {
      type: "category",
      data: taskNames,
      inverse: true,
      show: false,
    },
    graphic: [
      {
        type: "rect",
        left: 0, top: 0,
        shape: { width: "100%", height: headerHeight },
        style: { fill: "#f5f5f5", stroke: "#e0e0e0", lineWidth: 1 },
        z: 10,
      },
      {
        type: "line",
        left: 0,
        top: headerHeight / 2,
        shape: { x1: 0, y1: 0, x2: 9999, y2: 0 },
        style: { stroke: "#e0e0e0", lineWidth: 1 },
        z: 11,
      },
      {
        type: "text",
        left: "center",
        top: headerHeight / 4 - 7,
        z: 12,
        style: {
          text: "Time(Hr)",
          font: "bold 12px sans-serif",
          fill: "#333",
          textAlign: "center",
        },
      },
    ],
    series: [
      {
        type: "custom",
        renderItem: (params, api) => {
          const idx = api.value(0);
          const start = api.coord([api.value(1), idx]);
          const end   = api.coord([api.value(2), idx]);
          const height = api.size([0, 1])[1] * 0.55;
          return {
            type: "rect",
            shape: {
              x: start[0],
              y: start[1] - height / 2,
              width: end[0] - start[0],
              height,
            },
            style: api.style(),
          };
        },
        encode: { x: [1, 2], y: 0 },
        data: tasks.map((t, i) => ({
          value: [i, t.start, t.end],
          itemStyle: { color: "#4e8ef7" },
        })),
      },
    ],
  };
};