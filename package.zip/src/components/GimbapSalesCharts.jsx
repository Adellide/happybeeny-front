import React, { useState, useEffect, useRef, useMemo } from "react";
import * as echarts from "echarts";
import * as XLSX from "xlsx";
import EChartBase from "./charts/EChartBase";

// ─── 1. 샘플 데이터 생성기 ──────────────────────────────
const GIMBAP_TYPES = ["참치김밥", "치즈김밥", "야채김밥", "돈까스김밥"];
const DATES = ["2025-10-01T15:00:00", "2025-10-02T14:00:00", "2025-10-03T16:00:00", "2025-10-04T15:30:00", "2025-10-05T15:00:00", "2025-10-06T15:10:00", "2025-10-07T15:40:00", "2025-10-08T15:20:00"];

const generateSampleData = () => {
  const data = [];
  DATES.forEach((date) => {
    GIMBAP_TYPES.forEach((type) => {
      // 김밥 종류별로 기준값을 다르게 주어 분포의 차이를 만듭니다
      const baseAmount =
        type === "참치김밥" ? 120 :
        type === "치즈김밥" ? 90 :
        type === "야채김밥" ? 70 : 150;
      
      // 기준값에서 ±30 정도의 랜덤 변동 추가
      const amount = Math.max(0, Math.floor(baseAmount + (Math.random() * 60 - 30)));
      data.push({ date, type, amount });
    });
  });
  return data;
};

// ─── 2. 통계 계산 헬퍼 함수 (Boxplot 용) ────────────────
// 주어진 배열에서 백분위수(Percentile)를 계산합니다
const getPercentile = (sortedData, p) => {
  const index = (sortedData.length - 1) * p;
  const lower = Math.floor(index);
  const upper = Math.ceil(index);
  const weight = index % 1;
  if (upper >= sortedData.length) return sortedData[lower];
  return sortedData[lower] * (1 - weight) + sortedData[upper] * weight;
};

// 배열을 받아 [최소값, Q1, 중앙값, Q3, 최대값] 을 반환합니다.
const calculateBoxplotValues = (values) => {
  if (values.length === 0) return [0, 0, 0, 0, 0];
  const sorted = [...values].sort((a, b) => a - b);
  const min = sorted[0];
  const max = sorted[sorted.length - 1];
  const q1 = getPercentile(sorted, 0.25);
  const median = getPercentile(sorted, 0.5);
  const q3 = getPercentile(sorted, 0.75);
  
  return [min, q1, median, q3, max];
};

// ─── 3. 선형 회귀(Linear Regression) 및 R² 계산 헬퍼 함수 ──
const calculateRegressionAndR2 = (dataPoints) => {
  const n = dataPoints.length;
  if (n === 0) return null;

  const numericData = dataPoints
    .map(([date, value]) => {
      const time = new Date(date).getTime();
      return { time, value, date };
    })
    .filter((d) => !Number.isNaN(d.time));

  if (numericData.length === 0) return null;

  let sumX = 0, sumY = 0, sumXY = 0, sumX2 = 0;
  numericData.forEach(({ time, value }) => {
    sumX += time;
    sumY += value;
    sumXY += time * value;
    sumX2 += time * time;
  });

  const slope = (n * sumXY - sumX * sumY) / (n * sumX2 - sumX * sumX);
  const intercept = (sumY - slope * sumX) / n;

  const yMean = sumY / n;
  let ssTot = 0;
  let ssRes = 0;
  numericData.forEach(({ time, value }) => {
    ssTot += Math.pow(value - yMean, 2);
    const predicted = slope * time + intercept;
    ssRes += Math.pow(value - predicted, 2);
  });
  const rSquared = ssTot === 0 ? 1 : 1 - (ssRes / ssTot);

  const sortedByTime = [...numericData].sort((a, b) => a.time - b.time);
  const startX = sortedByTime[0].date;
  const endX = sortedByTime[sortedByTime.length - 1].date;
  const startY = slope * sortedByTime[0].time + intercept;
  const endY = slope * sortedByTime[sortedByTime.length - 1].time + intercept;

  return { slope, intercept, rSquared, startX, endX, startY, endY };
};

export default function GimbapSalesCharts() {
  const boxplotRef = useRef(null);

  const [showBoxplot, setShowBoxplot] = useState(true);


  // 데이터 초기화
  const salesData = useMemo(() => generateSampleData(), []);

  // ─── 상단 차트: 스캐터 option (EChartBase에 prop으로 전달) ──
  const scatterOption = useMemo(() => {
    const seriesData = GIMBAP_TYPES.map((type) => {
      const dataPoints = salesData
        .filter((d) => d.type === type)
        .map((d) => [d.date, d.amount]);

      const reg = calculateRegressionAndR2(dataPoints, DATES);

      return {
        name: type,
        type: "scatter",
        symbolSize: 12,
        data: dataPoints,
        markLine: reg ? {
          animation: false,
          symbol: ["none", "none"],
          lineStyle: { type: "solid", width: 2, opacity: 0.8 },
          label: {
            show: true,
            position: "end",
            formatter: `R²: ${reg.rSquared.toFixed(2)}`,
          },
          data: [
            [
              { coord: [reg.startX, reg.startY] },
              {
                coord: [reg.endX, reg.endY],
                name: `<strong>${type} 추세선</strong><br/>y = ${reg.slope.toFixed(2)}x ${reg.intercept >= 0 ? "+" : "-"} ${Math.abs(reg.intercept).toFixed(2)}<br/>R² = ${reg.rSquared.toFixed(4)}`,
              },
            ],
          ],
        } : undefined,
      };
    });

    return {
      title: { text: "일자별 김밥 판매량 (Scatter)", left: "center" },
      tooltip: {
        trigger: "item",
        formatter: (params) => {
          if (params.componentType === "markLine") return params.name;
          return `${params.seriesName}<br/>날짜: ${params.value[0]}<br/>판매량: ${params.value[1]}개`;
        },
      },
      legend: { top: 30, data: GIMBAP_TYPES },
      grid: { left: "5%", right: "10%", bottom: "10%", top: "25%", containLabel: true },
      xAxis: {
        type: "time",
        name: "판매 일자",
        axisLabel: {
          formatter: (value) => {
            const date = new Date(value);
            return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}-${String(date.getDate()).padStart(2, "0")}`;
          },
        },
        boundaryGap: ["5%", "5%"],
      },
      yAxis: { type: "value", name: "판매량" },
      series: seriesData,
    };
  }, [salesData]);

  // ─── 하단 차트: 박스플롯 (Boxplot) ───────────────────────
  useEffect(() => {
    if (!boxplotRef.current || !showBoxplot) return;
    const chart = echarts.init(boxplotRef.current);

    // 김밥 종류별 [최소값, Q1, 중앙값, Q3, 최대값] 계산
    const boxplotData = GIMBAP_TYPES.map((type) => {
      const amounts = salesData
        .filter((d) => d.type === type)
        .map((d) => d.amount);
      return calculateBoxplotValues(amounts);
    });

    // 스캐터(개별 점) 데이터 생성: x축이 category일 때 점들이 겹치지 않게 약간의 Jitter(가로 노이즈)를 줍니다.
    const scatterDataForBoxplot = salesData.map((d) => {
      const baseIdx = GIMBAP_TYPES.indexOf(d.type);
      // -0.15 ~ 0.15 사이의 랜덤 값을 더해 좌우로 분산시킵니다.
      const jitter = (Math.random() - 0.5) * 0.3; 
      return {
        name: d.type,
        value: [baseIdx + jitter, d.amount],
        date: d.date,
      };
    });

    const option = {
      title: { text: "김밥 종류별 판매량 분포 (Boxplot)", left: "center" },
      tooltip: {
        trigger: "item",
        formatter: (params) => {
          // 스캐터 점에 마우스를 올렸을 때의 툴팁 포맷
          if (params.seriesType === "scatter") {
            return `<strong>${params.data.name}</strong><br/>날짜: ${params.data.date}<br/>판매량: ${params.data.value[1]}개`;
          }
          // 박스플롯에 마우스를 올렸을 때의 툴팁 포맷
          const { name, value } = params;
          return `
            <strong>${name}</strong><br/>
            최대값(Max): ${value[5]}<br/>
            3사분위(Q3): ${value[4]}<br/>
            중앙값(Med): ${value[3]}<br/>
            1사분위(Q1): ${value[2]}<br/>
            최소값(Min): ${value[1]}
          `;
        },
      },
      grid: { left: "5%", right: "5%", bottom: "10%", top: "20%", containLabel: true },
      xAxis: [
        {
          type: "category",
          name: "김밥 종류",
          data: GIMBAP_TYPES,
        },
        {
          type: "value",
          show: false, // Jitter용 보조 X축 (숨김 처리)
          min: -0.5,
          max: GIMBAP_TYPES.length - 0.5,
        }
      ],
      yAxis: {
        type: "value",
        name: "판매량",
      },
      series: [
        {
          name: "판매량 분포",
          type: "boxplot",
          xAxisIndex: 0,
          data: boxplotData,
          itemStyle: {
            color: "#6366f1",
            borderColor: "#4338ca",
          },
        },
        {
          name: "개별 판매 데이터",
          type: "scatter",
          xAxisIndex: 1, // 보조 X축을 사용하여 점을 분산 배치
          symbolSize: 6,
          itemStyle: {
            color: "#f59e0b", // 주황색 점
            opacity: 0.8,
          },
          data: scatterDataForBoxplot,
        }
      ],
    };

    chart.setOption(option);

    const resizeObserver = new ResizeObserver(() => chart.resize());
    resizeObserver.observe(boxplotRef.current);

    return () => {
      resizeObserver.disconnect();
      chart.dispose();
    };
  }, [salesData, showBoxplot]);

    const downloadExcel = () => {
    // 1. 워크북(Excel 파일 객체) 생성
    const workbook = XLSX.utils.book_new();

    // 2. 전체 데이터 시트 생성
    const allDataForExcel = salesData.map(d => ({
      "날짜": d.date,
      "김밥 종류": d.type,
      "판매량": d.amount
    }));
    const allDataSheet = XLSX.utils.json_to_sheet(allDataForExcel);
    XLSX.utils.book_append_sheet(workbook, allDataSheet, "전체 데이터");

    // 3. 김밥 종류별로 다중 시트 생성
    GIMBAP_TYPES.forEach(type => {
      const typeData = salesData
        .filter(d => d.type === type)
        .map(d => ({ "날짜": d.date, "판매량": d.amount }));
      const typeSheet = XLSX.utils.json_to_sheet(typeData);
      XLSX.utils.book_append_sheet(workbook, typeSheet, type);
    });

    
    // 4. 실제 .xlsx 파일로 다운로드
    XLSX.writeFile(workbook, "김밥_판매량_데이터.xlsx");
  };

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: "24px", width: "100%", height: "800px", padding: "16px" }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
        <label style={{ display: "flex", alignItems: "center", gap: "8px", cursor: "pointer", fontWeight: "bold", color: "#334155" }}>
          <input 
            type="checkbox" 
            checked={showBoxplot} 
            onChange={(e) => setShowBoxplot(e.target.checked)} 
            style={{ width: "18px", height: "18px", cursor: "pointer" }}
          />
          박스플롯차트 보이기
        </label>
        <button 
          onClick={downloadExcel}
          style={{ padding: "8px 16px", backgroundColor: "#10b981", color: "white", border: "none", borderRadius: "6px", cursor: "pointer", fontWeight: "bold", boxShadow: "0 1px 3px rgba(0,0,0,0.1)" }}
        >
          엑셀(.xlsx) 다운로드
        </button>
      </div>
      <div style={{ flex: 1, minHeight: 0, border: "1px solid #e2e8f0", borderRadius: "12px", padding: "16px", background: "#fff" }}>
        <EChartBase option={scatterOption} style={{ height: "100%", width: "100%" }} />
      </div>
      {showBoxplot && (
        <div ref={boxplotRef} style={{ flex: 1, minHeight: 0, border: "1px solid #e2e8f0", borderRadius: "12px", padding: "16px", background: "#fff" }} />
      )}
    </div>
  );
}