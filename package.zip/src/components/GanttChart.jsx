import React, { useEffect, useRef } from "react";
import { Gantt, Willow } from "@svar-ui/react-gantt";
import "@svar-ui/react-gantt/all.css";

const columns = [
  {
    id: "baseId",
    width: 80,
    align: "center",
    header: [
      { text: "기본ID", rowspan: 2 },
    ],
  },
  {
    id: "head",
    width: 80,
    align: "center",
    header: [
      { text: "Head", rowspan: 2 },
    ],
  },
  {
    id: "text",
    width: 120,
    align: "center",
    header: [
      { text: "Base Nm", rowspan: 2 },
    ],
  },
  {
    id: "x",
    width: 60,
    align: "center",
    header: [
      { text: "DY", colspan: 2 },
      { text: "X" },
    ],
  },
  {
    id: "y",
    width: 60,
    align: "center",
    header: [
      "",
      { text: "Y" },
    ],
  },
];

const scales = [
  { unit: "hour", step: 1, format: "Time(Hr)" },
  { unit: "minute", step: 12, format: (d) =>
    (d.getMinutes() / 60).toFixed(1)
  },
];
/*
const scales = [
  {
    unit: "hour",
    step: 1,
    format: "Time(Hr)",   // 윗줄 헤더 텍스트
  },
  {
    unit: "minute",
    step: 12,              // 1시간을 5칸으로 나눔 (0.0, 0.2, 0.4, 0.6, 0.8)
    format: (date) => {
      const val = date.getMinutes() / 60;
      return val.toFixed(1); // "0.0", "0.2", ..., "0.8"
    },
  },
];
*/

const hrToDate = (hr) => {
  const minutes = Math.round(hr * 60);
  return new Date(2024, 0, 1, 0, minutes);
};

export default function GanttChart({  }) {
  const tasks = [
  {
    id: 1,
    text: "요구사항 분석",
    baseId: "Task 1",
    head: "H1",
    x: 10,
    y: 10,
    start: new Date(2024, 0, 1, 0, 0),
    end:   new Date(2024, 0, 1, 0, 48),
    type: "task",
  },
];

  return (
    <Willow>
      <Gantt
        tasks={tasks}
        scales={scales}
        columns={columns}
        start={new Date(2024, 0, 1, 0, 0)}
        end={new Date(2024, 0, 1, 1, 0)}
      />
    </Willow>
  );
}