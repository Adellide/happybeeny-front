import React from "react";
import { Gantt, ViewMode } from "gantt-task-react";
import "gantt-task-react/dist/index.css";

export default function GanttChart() {
  // Date 월은 0부터 시작합니다 (9 = 10월)
  const tasks = [
    {
      start: new Date(2025, 9, 1),
      end: new Date(2025, 9, 5),
      name: "요구사항 분석",
      id: "Task 1",
      type: "task",
      progress: 100,
      styles: { progressColor: "#3b82f6", progressSelectedColor: "#2563eb" },
    },
    {
      start: new Date(2025, 9, 4),
      end: new Date(2025, 9, 12),
      name: "시스템 설계",
      id: "Task 2",
      type: "task",
      progress: 60,
      dependencies: ["Task 1"],
      styles: { progressColor: "#10b981", progressSelectedColor: "#059669" },
    },
    {
      start: new Date(2025, 9, 10),
      end: new Date(2025, 9, 20),
      name: "API 개발",
      id: "Task 3",
      type: "task",
      progress: 40,
      dependencies: ["Task 2"],
      styles: { progressColor: "#f59e0b", progressSelectedColor: "#d97706" },
    },
    {
      start: new Date(2025, 9, 15),
      end: new Date(2025, 9, 25),
      name: "프론트엔드 개발",
      id: "Task 4",
      type: "task",
      progress: 20,
      dependencies: ["Task 2"],
      styles: { progressColor: "#8b5cf6", progressSelectedColor: "#7c3aed" },
    },
    {
      start: new Date(2025, 9, 24),
      end: new Date(2025, 9, 31),
      name: "통합 테스트 및 배포",
      id: "Task 5",
      type: "task",
      progress: 0,
      dependencies: ["Task 3", "Task 4"],
      styles: { progressColor: "#ef4444", progressSelectedColor: "#dc2626" },
    },
  ];

  return (
    <div style={{ padding: "20px", background: "#fff", borderRadius: "12px", border: "1px solid #e2e8f0" }}>
      <h2 style={{ textAlign: "center", marginBottom: "30px", color: "#334155" }}>프로젝트 일정 관리 (Real Gantt)</h2>
      <Gantt
        tasks={tasks}
        viewMode={ViewMode.Day}
        locale="ko"
        columnWidth={65}
        listCellWidth="155px"
      />
    </div>
  );
}
