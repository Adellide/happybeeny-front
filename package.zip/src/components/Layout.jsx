import React from "react";
import { Link, Outlet } from "react-router-dom";

const navStyle = { 
  display: "flex", 
  gap: "24px", 
  padding: "16px 24px", 
  background: "#ffffff", 
  borderBottom: "1px solid #e2e8f0",
  boxShadow: "0 1px 2px 0 rgba(0, 0, 0, 0.05)"
};

const linkStyle = { textDecoration: "none", color: "#334155", fontWeight: "bold", fontSize: "16px" };

export default function Layout() {
  return (
    <div className="app-layout" style={{ display: "flex", flexDirection: "column", height: "100vh" }}>
      {/* 상단 네비게이션 메뉴 */}
      <nav style={navStyle}>
        <Link to="/" style={linkStyle}>Main</Link>
        <Link to="/tuna" style={linkStyle}>참치</Link>
        <Link to="/beef" style={linkStyle}>쇠고기</Link>
        <Link to="/veggie" style={linkStyle}>야채</Link>
        <Link to="/gantt" style={linkStyle}>일정(Gantt)</Link>
      </nav>
      
      {/* 하위 라우트 컴포넌트가 렌더링되는 영역 (Outlet) */}
      <main style={{ flex: 1, padding: "20px", overflow: "auto", backgroundColor: "#f1f5f9" }}>
        <Outlet />
      </main>
    </div>
  );
}
