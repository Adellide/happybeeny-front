import React from "react";
import AppRouter from "./AppRouter";

export default function App() {
  // AppRouter를 통해 상단 메뉴(Layout)와 라우팅을 처리합니다.
  return <AppRouter />;
}