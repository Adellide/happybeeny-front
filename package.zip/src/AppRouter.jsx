import React, { useState } from "react";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Layout from "./Layout";
import ParentGrid from "./components/ParentGrid";
import GimbapSalesCharts from "./components/GimbapSalesCharts";
import CombinedAnalysisPopup from "./components/CombinedAnalysisPopup";
import GanttChart from "./components/GanttChart";
import GanttEchart from "./components/charts/gantt/GanttEchart";
import SyncBarCharts from "./components/SyncBarCharts";
const MainPage = () => {
  const [popupOpen, setPopupOpen] = useState(false);
  const [selectedRow, setSelectedRow] = useState(null);

  const handleRowDoubleClick = (row) => {
    setSelectedRow(row);
    setPopupOpen(true);
  };

  return (
    <div style={{ fontFamily: "sans-serif", color: "#333" }}>
      <header style={{ marginBottom: "20px", paddingBottom: "10px", borderBottom: "1px solid #ccc" }}>
        <span style={{ fontSize: "24px", fontWeight: "bold", marginRight: "10px" }}>Statistical Analysis Dashboard</span>
        <span style={{ fontSize: "14px", color: "#666" }}>Correlation &amp; Regression Explorer</span>
      </header>
      <div style={{ padding: "10px", background: "#f8f9fa", borderRadius: "8px" }}>
        <ParentGrid onRowDoubleClick={handleRowDoubleClick} />
      </div>
      {popupOpen && (
        <CombinedAnalysisPopup
          rowData={selectedRow}
          onClose={() => setPopupOpen(false)}
        />
      )}
    </div>
  );
};

const TunaPage = () => <div><h2>참치김밥 데이터</h2><GimbapSalesCharts /></div>;
const BeefPage = () => <div><h2>쇠고기김밥 데이터</h2><GimbapSalesCharts /></div>;
const VeggiePage = () => <div><h2>야채김밥 데이터</h2><GimbapSalesCharts /></div>;
const GanttPage = () => <div><h2>프로젝트 일정 관리</h2><GanttChart /></div>;
const EGanttPage = () => <div><h2>김밥시간</h2><GanttEchart /></div>;
const SyncChartsPage = () => <div><h2>동기화 차트 (SyncBarCharts)</h2><SyncBarCharts /></div>;
export default function AppRouter() {
  return (
    <BrowserRouter>
      <Routes>
        {/* Layout 컴포넌트가 부모 라우트가 되며 메뉴와 Outlet을 제공합니다 */}
        <Route path="/" element={<Layout />}>
          {/* index 라우트는 "/" 경로일 때 Outlet 자리에 렌더링됩니다 */}
          <Route index element={<MainPage />} />
          
          {/* 각각의 서브 경로에 맞는 컴포넌트 설정 */}
          <Route path="tuna" element={<TunaPage />} />
          <Route path="beef" element={<BeefPage />} />
          <Route path="veggie" element={<VeggiePage />} />
          <Route path="gantt" element={<GanttPage />} />
          <Route path="egantt" element={<EGanttPage />} />
<Route path="/sync-charts" element={<SyncBarCharts />} />
        </Route>
      </Routes>
    </BrowserRouter>
  );
}
